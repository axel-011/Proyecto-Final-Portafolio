namespace AxelPortfolio.Models
{
    public class Project
    {
        public string? Name { get; set; }
        public string? Description { get; set; }
        public string? Technologies { get; set; }
        public string? RepositoryUrl { get; set; }
    }
}
