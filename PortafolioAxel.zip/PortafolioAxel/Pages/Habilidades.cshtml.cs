using Microsoft.AspNetCore.Mvc.RazorPages;

namespace PortafolioAxel.Pages
{
    public class HabilidadesModel : PageModel
    {
        public void OnGet()
        {
            // Aquí puedes agregar lógica adicional si es necesario.
        }
    }
}
